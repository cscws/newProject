//
//  VCModel.h
//  Life
//
//  Created by jie.huang on 27/3/19.
//  Copyright © 2019年 jie.huang. All rights reserved.
//
NS_ASSUME_NONNULL_BEGIN

@interface VCModel : NSObject

@property (nonatomic,strong) NSString *vcName;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *imageName;
@property (nonatomic,strong) NSString *imageNameClick;
@property (nonatomic,strong) NSString *navColor;
@property (nonatomic,strong) NSString *StoryboardNmae;
@property (nonatomic,strong) NSString *StoryboarID;

@end

NS_ASSUME_NONNULL_END
