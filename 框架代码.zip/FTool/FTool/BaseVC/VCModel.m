//
//  VCModel.m
//  Life
//
//  Created by jie.huang on 27/3/19.
//  Copyright © 2019年 jie.huang. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "VCModel.h"

@implementation VCModel

@end
