
#import <UIKit/UIKit.h>
@interface NSObject (MJParse)


+ (id)MTMJParse:(id)responseObj;

@end
