#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JRunTabBarController : UITabBarController


+(JRunTabBarController *)creatTabBarJsonName:(NSString *)fileName customTabbar:(NSString *)tabBarName;

@end

NS_ASSUME_NONNULL_END
