
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JRunNavController : UINavigationController

@property(nonatomic ,assign) BOOL isPopDisabled;

@end

NS_ASSUME_NONNULL_END
