//
//  Stubs.h
//  Life
//
//  Created by jie.huang on 28/3/19.
//  Copyright © 2019年 jie.huang. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Stubs : NSObject

+ (void)installStubs;

+ (void)removeStubs;

@end
