//
//  NSDictionary+Tool.h
//  Run
//
//  Created by jie.huang on 20/1/2020.
//  Copyright © 2020 microcrystal. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (Tool)

- (NSString *)toString;

@end

NS_ASSUME_NONNULL_END
