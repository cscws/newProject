//
//  MoreCollectionCell.h
//  Life
//
//  Created by jie.huang on 4/4/19.
//  Copyright © 2019年 jie.huang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MoreCollectionCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *TitleLable;

@end

NS_ASSUME_NONNULL_END
