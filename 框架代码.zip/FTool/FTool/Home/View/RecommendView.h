//
//  RecommendView.h
//  Life
//
//  Created by jie.huang on 5/4/19.
//  Copyright © 2019年 jie.huang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RecommendView : UIView
@property (weak, nonatomic) IBOutlet UICollectionView *CollectionView;

@end

NS_ASSUME_NONNULL_END
