//
//  DataModel.h
//  MAIHealth
//
//  Created by jie.huang on 26/2/19.
//  Copyright © 2019年 MAITIAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataModel : NSObject

@property (nonatomic,strong) NSString *Name;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *imageurl;
@property (nonatomic,strong) NSString *content;


@end
