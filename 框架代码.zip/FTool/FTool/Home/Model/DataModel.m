//
//  DataModel.m
//  MAIHealth
//
//  Created by jie.huang on 26/2/19.
//  Copyright © 2019年 MAITIAN. All rights reserved.
//

#import "DataModel.h"

@implementation DataModel

@end
