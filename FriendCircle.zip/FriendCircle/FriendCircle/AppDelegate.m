//
//  AppDelegate.m
//  FriendCircle
//
//  Created by 闪闪的少女 on 2022/2/23.
//

#import "AppDelegate.h"
#import "MainTabBarController.h"
@interface AppDelegate ()
@property (nonatomic, strong) UIWindow *wind;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    _wind = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    MainTabBarController *vc = [[MainTabBarController alloc]init];
    _wind.rootViewController = vc;
    [_wind makeKeyAndVisible];
    
    return YES;
}


#pragma mark - UISceneSession lifecycle
@end
