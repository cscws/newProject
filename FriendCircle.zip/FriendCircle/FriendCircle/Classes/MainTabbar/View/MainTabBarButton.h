//
//  MainTabBarButton.h
//  cmbfaeApp
//
//  Created by 余钦 on 16/4/7.
//  Copyright © 2016年 cmbfae Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabBarButton : UIButton
@property(nonatomic, strong)UITabBarItem *tabBarItem;
@end
