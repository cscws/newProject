//
//  SHFriendTimeLineType.m
//  SHFriendTimeLineUI
//
//  Created by CSH on 2017/1/12.
//  Copyright © 2017年 CSH. All rights reserved.
//

#import "SHFriendTimeLineType.h"

@implementation SHFriendTimeLineType

@end
