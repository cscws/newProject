//
//  SHCustomRefreshFooter.m
//  SHFriendTimeLineUI
//
//  Created by CSH on 2017/4/17.
//  Copyright © 2017年 CSH. All rights reserved.
//

#import "SHCustomRefreshFooter.h"

@implementation SHCustomRefreshFooter

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
