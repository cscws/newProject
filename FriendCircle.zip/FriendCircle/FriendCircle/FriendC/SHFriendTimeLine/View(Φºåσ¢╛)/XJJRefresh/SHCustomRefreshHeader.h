//
//  SHCustomRefreshHeader.h
//  SHFriendTimeLineUI
//
//  Created by CSH on 2017/4/17.
//  Copyright © 2017年 CSH. All rights reserved.
//

#import "MJRefreshHeader.h"

@interface SHCustomRefreshHeader : MJRefreshHeader

@end
