//
//  SceneDelegate.h
//  FriendCircle
//
//  Created by 闪闪的少女 on 2022/2/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@end

